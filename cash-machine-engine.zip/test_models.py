import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

for model in client.models.list():
    print(model.name)

    methods = getattr(model, "supported_actions", None)
    if methods:
        print("   ", methods)